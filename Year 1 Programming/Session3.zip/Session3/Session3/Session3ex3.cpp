// Description: example of a struct in use

#include "stdafx.h"
#include <iostream>
using namespace std;

struct Simple
{
	int Element1;
	double Element2;
}; // note the semicolon

double PointlessFunction(Simple ArbitraryParameter);

int main()
{
	Simple AVariable = {99, 2.5}; //doing some initialising
	Simple BVariable;
	double ResultA;
	double ResultB;
	
	// setting values for parts of the struct
	BVariable.Element1 =-42;
	BVariable.Element2 = 3.14159;
	// passing a variable of our new type Simple to a function 
	ResultA= PointlessFunction(AVariable);
	ResultB= PointlessFunction(BVariable);
	cout<<"Value of ResultA  "<<ResultA<<endl;
	cout<<"Value of ResultB  "<<ResultB<<endl;
	
	return 0;
}

double PointlessFunction(Simple ArbitraryParameter)
{
	// this pointless function is purely to show how to access elements of a struct passed as a parameter
	return (ArbitraryParameter.Element1+ArbitraryParameter.Element2);
}
